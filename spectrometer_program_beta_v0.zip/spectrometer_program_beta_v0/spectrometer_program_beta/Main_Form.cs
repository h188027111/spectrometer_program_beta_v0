﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;


using FTD2XX_NET;
using System.IO;

namespace spectrometer_program_beta
{
    public partial class Main_Form : Form
    {
        public bool Check_Pass = false;
        public bool Run = false;
        public double T = 0;
        public double F = 0;
        public double R = 0;
        bool D_R = false;
        bool S_R = false;
        string dataToWrite = "";
        UInt32 numBytesWritten = 0;
        UInt32 numBytesAvailable = 7296;
        // Now that we have the amount of data we want available, read it
        byte[] readData = new byte[7300];
        UInt32 numBytesRead = 7296;

        int[] Data_p = new int[3650];

        Bitmap bmp_p = new Bitmap(1824, 10);
        Bitmap bmp_sensor = new Bitmap(3648, 800);
        //int alpha_bar = 0;
        int FPS_c = 0;
        int min_c = 0;
        int max_c = 0;
        int min_p = 0;
        int max_p = 0;
        int max_l = 0;
        int alpha_p1 = 0;
        int alpha_p2 = 0;
        //private static System.Timers.Timer CheckUpdatetimer = new System.Timers.Timer();
        //private DataTable myTab = new DataTable("mytab");

        //**************************************************************************************//
        //Definition:
        //  FT_STATUS FT_SetVIDPID(DWORD dwVID, DWORD dwPID)
        //Parameters:
        //  dwVID Device Vendor ID(VID)
        //  dwPID Device Product ID(PID)
        //Return Value:
        //  FT_OK if successful, otherwise the return value is an FT error code.

        UInt32 ftdiDeviceCount = 0;
        FTDI.FT_STATUS ftStatus = FTDI.FT_STATUS.FT_OK;

        // Create new instance of the FTDI device class
        FTDI myFtdiDevice = new FTDI();
        //**************************************************************************************//
        public Main_Form()
        {
            InitializeComponent();
            ftStatus = myFtdiDevice.GetNumberOfDevices(ref ftdiDeviceCount);
            FTDI.FT_DEVICE_INFO_NODE[] ftdiDeviceList = new FTDI.FT_DEVICE_INFO_NODE[ftdiDeviceCount];
            ftStatus = myFtdiDevice.GetDeviceList(ftdiDeviceList);
            if (0 < ftdiDeviceList.Length)
            {
                for (int i = 0; i < ftdiDeviceList.Length; i++)
                {
                    comboBox_Selected_SerialPort.Items.Add(ftdiDeviceList[i].Description.ToString());
                }
                if (!string.IsNullOrWhiteSpace(ftdiDeviceList[0].Description.ToString()))
                {
                    comboBox_Selected_SerialPort.SelectedIndex = 0;
                }
                else
                {
                    MessageBox.Show("请先检查设备是否已连接到您的电脑=-=若尚未未连请先关闭程序、连接您的设备后再开启程序", "警告信息", MessageBoxButtons.OK,MessageBoxIcon.Information);
                    return;
                }
            }
            else
            {
                MessageBox.Show("********************************************************\n 请先检查设备是否已连接到您的电脑=-=若尚未未连请先关闭程序、连接您的设备后再开启程序、若您已连接您的设备到此计算机、那么就说明你很有可能没有安装正确的驱动程序=-=请安装FT245 USB转串口 驱动程序 \n                →→ =-= ←←                \n********************************************************", "警告信息", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
        }

        private void START_Click(object sender, EventArgs e)
        {
            if (Check_Pass)
            {
                Run = true;
                S_R = true;
                uint R_uint = Convert.ToUInt32(R);

                ftStatus = myFtdiDevice.SetBaudRate(R_uint);

                if (ftStatus != FTDI.FT_STATUS.FT_OK)
                {
                    // Wait for a key press
                    MessageBox.Show("Failed to set Baud rate (error " + ftStatus.ToString() + ")","警告信息", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }

                // Set data characteristics - Data bits, Stop bits, Parity
                ftStatus = myFtdiDevice.SetDataCharacteristics(FTDI.FT_DATA_BITS.FT_BITS_8, FTDI.FT_STOP_BITS.FT_STOP_BITS_1, FTDI.FT_PARITY.FT_PARITY_NONE);
                if (ftStatus != FTDI.FT_STATUS.FT_OK)
                {
                    // Wait for a key press
                    MessageBox.Show("Failed to set data characteristics (error " + ftStatus.ToString() + ")", "警告信息", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }

                // Set flow control - set RTS/CTS flow control
                ftStatus = myFtdiDevice.SetFlowControl(FTDI.FT_FLOW_CONTROL.FT_FLOW_RTS_CTS, 0x11, 0x13);
                if (ftStatus != FTDI.FT_STATUS.FT_OK)
                {
                    // Wait for a key press
                    MessageBox.Show("Failed to set flow control (error " + ftStatus.ToString() + ")", "警告信息", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }

                // Set read timeout to 5 seconds, write timeout to infinite
                ftStatus = myFtdiDevice.SetTimeouts(5000, 0);
                if (ftStatus != FTDI.FT_STATUS.FT_OK)
                {
                    // Wait for a key press
                    MessageBox.Show("Failed to set timeouts (error " + ftStatus.ToString() + ")", "警告信息", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }

                // Perform loop back - make sure loop back connector is fitted to the device
                // Write string data to the device
                

                //**************************************************************************************//
                //                                检测CCD积分时间并发送至设备                           //
                if (10 <= T && T < 1000)
                {
                    dataToWrite = "#IT:" + T.ToString().PadLeft(3, '0') + "us%";
                    MessageBox.Show("\n\n**********************\n\n" + dataToWrite + "\n\n**********************\n\n");
                    ftStatus = myFtdiDevice.Write(dataToWrite, dataToWrite.Length, ref numBytesWritten);
                }
                else if (1000 <= T && T <= 1000000)
                {
                    int T_ms = Convert.ToInt32(T / 1000);
                    dataToWrite = "#IT:" + T_ms.ToString().PadLeft(3, '0') + "ms%";
                    MessageBox.Show("\n\n**********************\n\n" + dataToWrite + "\n\n**********************\n\n");
                    ftStatus = myFtdiDevice.Write(dataToWrite, dataToWrite.Length, ref numBytesWritten);
                }
                else if (1000000 <= T && T < 10000000)
                {
                    int T_s = Convert.ToInt32(T / 1000000);
                    dataToWrite = "#IT:" + T_s.ToString().PadLeft(3, '0') + "ss%";
                    MessageBox.Show("\n\n**********************\n\n" + dataToWrite + "\n\n**********************\n\n");
                    ftStatus = myFtdiDevice.Write(dataToWrite, dataToWrite.Length, ref numBytesWritten);
                }
                else
                {
                    MessageBox.Show("CCD积分时间设置有误", "警告信息", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }
                //**************************************************************************************//
                Thread newThread_update_c = new Thread(update_chart);
                Thread newThread_update_p = new Thread(update_picture_box);
                START.Enabled = false;
                newThread_update_c.Start();
                newThread_update_p.Start();
                //**************************************************************************************//
            }
            else
            {
                MessageBox.Show("请检查设置选项卡是否有误", "警告信息", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
        }

//******************************************************************************************************************************************************//
        private void update_chart()
        {
            while ( Run )
            {
                min_c = 65535;
                max_c = 0;
                FPS_c = (int)(1000 / F);
                if (FPS_c < (int)(T / 100) && 200 < (int)(T / 100))
                {
                    FPS_c = (int)(T / 100);
                }
                Thread.Sleep(FPS_c);
                this.BeginInvoke(new Action(() =>
                {
                    dataToWrite = "#?data%";
                    // Note that the Write method is overloaded, so can write string or byte array data
                    ftStatus = myFtdiDevice.Write(dataToWrite, dataToWrite.Length, ref numBytesWritten);
                    if (ftStatus != FTDI.FT_STATUS.FT_OK && Run)
                    {
                        // Wait for a key press
                        Run = false;
                        START.Enabled = false;
                        MessageBox.Show("Failed to write to device (error " + ftStatus.ToString() + ")" + "\n" + "****************************************************" + "\n" + " 程序运行出错、程序启动键已锁定、请按暂停后重新检测您的设备的参数设置以及连接情况、保存设置后再重新开始采集数据=-=" + "\n" + "****************************************************", "警告信息", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        return;
                    }
                    // Check the amount of data available to read
                    // In this case we know how much data we are expecting, 
                    // so wait until we have all of the bytes we have sent.
                    // Note that the Read method is overloaded, so can read string or byte array data
                    //ftStatus = myFtdiDevice.Read(out readData, numBytesAvailable, ref numBytesRead);
                    ftStatus = myFtdiDevice.Read(readData, numBytesAvailable, ref numBytesRead);
                    if (ftStatus != FTDI.FT_STATUS.FT_OK && Run)
                    {
                        // Wait for a key press
                        Run = false;
                        START.Enabled = false;
                        MessageBox.Show("Failed to read data (error " + ftStatus.ToString() + ")" + "\n" + "****************************************************" + "\n" + " 程序运行出错、程序启动键已锁定、请按暂停后重新检测您的设备的参数设置以及连接情况、保存设置后再重新开始采集数据=-=" + "\n" + "****************************************************", "警告信息", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        return;
                    }
                    else if(Run)
                    {
                        chart1.Series[0].Points.Clear();
                        for (int i = 0; i < 7296; i += 2)
                        {
                            Data_p[i / 2] = (int)(readData[i]) * 256 + (int)(readData[i + 1]);
                            if (min_c > Data_p[i / 2])
                            {
                                min_c = Data_p[i / 2];
                            }
                            if (max_c < Data_p[i / 2])
                            {
                                max_c = Data_p[i / 2];
                            }
                            chart1.Series[0].Points.AddXY(i / 2, Data_p[i / 2]);
                        }
 
                        chart1.ChartAreas[0].AxisY.Minimum = min_c;
                        chart1.ChartAreas[0].AxisY.Maximum = max_c;
                        if(!Run)
                        {
                            Run = false;
                            START.Enabled = false;
                            ftStatus = myFtdiDevice.Close();
                            return;
                        }
                    }
                }));

            }
            return;
        }
//******************************************************************************************************************************************************//

//******************************************************************************************************************************************************//
        private void update_picture_box()
        {
            while (Run)
            {
                min_c = 65535;
                max_c = 0;
                FPS_c = (int)(1000 / F);
                if (FPS_c < (int)(T /100) && 200 < (int)(T / 100))
                {
                    FPS_c = (int)(T / 100);
                }
                Thread.Sleep(FPS_c);
                this.BeginInvoke(new Action(() =>
                {
                    min_p = 65535;
                    max_p = 0;
                    max_l = 0;
                    for (int i = 0; i < 3648; i ++ )
                    {
                        if (i > 4 && i < 3643)
                        {
                            if (min_p > Data_p[i])
                            {
                                min_p = Data_p[i];
                            }
                            else if (max_p < Data_p[i])
                            {
                                max_p = Data_p[i];
                                max_l = i;
                            }
                        }
                    }
                    for (int i = 0; i < 1824; i++ )
                    {
                        
                        for (int j = 0; j < 10; j++ )
                        {
                            if (i > 2 && i < 1821)
                            {
                                alpha_p1 = 0;
                                if ((Data_p[i * 2] + Data_p[i * 2 + 1]) != 0 && max_p > 0)
                                {
                                    alpha_p1 = Convert.ToInt16(255 - (255 * (Data_p[i * 2] + Data_p[i * 2 + 1]) / (max_p * 2)));
                                }
                                bmp_p.SetPixel(i, j, Color.FromArgb( 255, 255 - alpha_p1, 255 - alpha_p1, 255 - alpha_p1));
                            }
                            else
                            {
                                bmp_p.SetPixel(i, j, Color.FromArgb(255, 0, 0, 0));
                            }
                        }

                    }
                    this.show_max_label.Text = string.Format("|   峰值:{0}   (0~65535)  |   峰值坐标:{1}   Pixel  |", max_p, max_l);
                    pictureBox1.Image = bmp_p;
                }));
            }
            return;
        }
//******************************************************************************************************************************************************//
        private void Setting_Save_Click(object sender, EventArgs e)
        {
            bool a1 = false;
            bool a2 = false;
            bool a4 = false;
            // 如果输入内容为空
            if (string.IsNullOrWhiteSpace(textBox_integral_time.Text.Trim()) || string.IsNullOrWhiteSpace(textBox_FPS.Text.Trim()))
            {
                MessageBox.Show("请设置CCD积分时间及光谱图像刷新率", "警告信息", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            // 验证参数设置是否有误
            T = Convert.ToDouble(textBox_integral_time.Text.Trim());
            F = Convert.ToDouble(textBox_FPS.Text.Trim());
            R = Convert.ToDouble(textBox_Baud_rate.Text.Trim());
            if (10 <= T && T <= 10000000 && 0 < F && F <= 5)
            {
                a1 = true;
            }
            else
            {
                MessageBox.Show("输入参数有误", "警告信息", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            //ComboBox cb = sender as ComboBox;
            string itemText = comboBox_Selected_SerialPort.SelectedItem as String;
            if (!string.IsNullOrWhiteSpace(itemText))
            {
                START.Enabled = true;
                MessageBox.Show(itemText, "当前使用串口设备为：", MessageBoxButtons.OK, MessageBoxIcon.Information);
                a2 = true;
            }
            else
            {
                MessageBox.Show("未检测到可用设备", "警告信息", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            if (a1 && a2)
            {
                ftStatus = myFtdiDevice.Close();
                ftStatus = myFtdiDevice.OpenByDescription(itemText);
                if (ftStatus != FTDI.FT_STATUS.FT_OK)
                {
                    MessageBox.Show("当前无法正确连接到您所选的设备=-=", "警告信息", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }
                else
                {
                    Check_Pass = true;
                    this.information_label.Text = string.Format("连接设备:{0}   |   波特率:{1}   |   CCD积分时间:{2}us   |   图像刷新:{3}FPS   |", itemText, R, T, F);
                }
            }
            else
            {
                this.information_label.Text = string.Format("请先到设置选项卡设置相关参数=-=", "警告信息", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void button_STOP_Click(object sender, EventArgs e)
        {
            Run = false;
            if (S_R)
            {
                D_R = true;
            }
            START.Enabled = false;
            // Close our device
            ftStatus = myFtdiDevice.Close();
            MessageBox.Show("Press any key to continue."+ "\n" + "****************************************************" + "\n" + "程序启动键已锁定、请按暂停后重新检测您的设备的参数设置以及连接情况、保存设置后再重新开始采集数据=-=" + "\n" + "****************************************************" + "\n", "警告信息", MessageBoxButtons.OK, MessageBoxIcon.Information);
            return;
        }

        private void button_rescan_device_Click(object sender, EventArgs e)
        {
            ftStatus = myFtdiDevice.GetNumberOfDevices(ref ftdiDeviceCount);
            FTDI.FT_DEVICE_INFO_NODE[] ftdiDeviceList = new FTDI.FT_DEVICE_INFO_NODE[ftdiDeviceCount];
            ftStatus = myFtdiDevice.GetDeviceList(ftdiDeviceList);
            if (0 < ftdiDeviceList.Length)
            {
                for (int i = 0; i < ftdiDeviceList.Length; i++)
                {
                    comboBox_Selected_SerialPort.Items.Add(ftdiDeviceList[i].Description.ToString());
                }
                if (!string.IsNullOrWhiteSpace(ftdiDeviceList[0].Description.ToString()))
                {
                    comboBox_Selected_SerialPort.SelectedIndex = 0;
                }
                else
                {
                    MessageBox.Show("请先检查设备是否已连接到您的电脑=-=若尚未未连请先关闭程序、连接您的设备后再开启程序", "警告信息", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }
            }
            else
            {
                MessageBox.Show("********************************************************\n 请先检查设备是否已连接到您的电脑=-=若尚未未连请先关闭程序、连接您的设备后再开启程序、若您已连接您的设备到此计算机、那么就说明你很有可能没有安装正确的驱动程序=-=请安装FT245 USB转串口 驱动程序 \n                →→ =-= ←←                \n********************************************************", "警告信息", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            return;
        }

        private void button_pause_Click(object sender, EventArgs e)
        {
            Run = false;
            if (S_R)
            {
                D_R = true;
            }
            START.Enabled = true;
            MessageBox.Show("程序已暂停", "提示信息", MessageBoxButtons.OK, MessageBoxIcon.Information);
            return;
        }

        private void button_save_data_Click(object sender, EventArgs e)
        {
            if (!Run && D_R )
            {
                string FILE_NAME = DateTime.Now.Year.ToString() + "_" + DateTime.Now.Month.ToString() + "_" + DateTime.Now.DayOfWeek.ToString() + "_" + DateTime.Now.DayOfYear.ToString() + "_" + DateTime.Now.Hour.ToString() + "_" + DateTime.Now.Minute.ToString() + "_" + DateTime.Now.Second.ToString();
                StreamWriter sw = new StreamWriter(FILE_NAME + "_" + Convert.ToDouble(textBox_integral_time.Text.Trim()) + "us" + ".txt");
                string w = "";
                for (int i = 0; i < 3648; i ++ )
                {
                    w = w + " " + Data_p[i];
                }
                sw.Write(w);
                sw.Close();

                chart1.SaveImage(FILE_NAME + "_" + Convert.ToDouble(textBox_integral_time.Text.Trim()) + "us" + ".Bmp", System.Windows.Forms.DataVisualization.Charting.ChartImageFormat.Bmp);
                chart1.SaveImage(FILE_NAME + "_" + Convert.ToDouble(textBox_integral_time.Text.Trim()) + "us" + ".Png", System.Windows.Forms.DataVisualization.Charting.ChartImageFormat.Png);
                for ( int i = 0; i < 3648; i ++ )
                {
                    if (i > 4 && i < 3644)
                    {
                        if (min_p > Data_p[i])
                        {
                            min_p = Data_p[i];
                        }
                        else if (max_p < Data_p[i])
                        {
                            max_p = Data_p[i];
                        }
                    }
                }
                for (int i = 0; i < 3648; i++ )
                {

                    for (int j = 0; j < 800; j++ )
                    {
                        if (i > 4 && i < 3644)
                        {
                            alpha_p2 = 0;
                            if (Data_p[i] != 0 && max_p > 0)
                            {
                                alpha_p2 = Convert.ToInt16(255 - 255 * Data_p[i] / max_p);
                            }
                            bmp_sensor.SetPixel(i, j, Color.FromArgb(255, 255 - alpha_p2, 255 - alpha_p2, 255 - alpha_p2));
                        }
                        else
                        {
                            bmp_sensor.SetPixel(i, j, Color.FromArgb(255, 0, 0, 0));
                        }
                    }

                }
                bmp_sensor.Save(FILE_NAME + "_sensor_" + Convert.ToDouble(textBox_integral_time.Text.Trim()) + "us" + ".Png", System.Drawing.Imaging.ImageFormat.Png);
            }
            else if( Run | !D_R )
            {
                if (Run)
                {
                    START.Enabled = true;
                    Run = false;
                    string FILE_NAME = DateTime.Now.Year.ToString() + "_" + DateTime.Now.Month.ToString() + "_" + DateTime.Now.DayOfWeek.ToString() + "_" + DateTime.Now.DayOfYear.ToString() + "_" + DateTime.Now.Hour.ToString() + "_" + DateTime.Now.Minute.ToString() + "_" + DateTime.Now.Second.ToString();
                    StreamWriter sw = new StreamWriter(FILE_NAME + "_" + Convert.ToDouble(textBox_integral_time.Text.Trim()) + "us" + ".txt");
                    string w = "";
                    for (int i = 0; i < 3648; i++)
                    {
                        w = w + " " + Data_p[i];
                    }
                    sw.Write(w);
                    sw.Close();

                    chart1.SaveImage(FILE_NAME + "_" + Convert.ToDouble(textBox_integral_time.Text.Trim()) + "us" + ".Bmp", System.Windows.Forms.DataVisualization.Charting.ChartImageFormat.Bmp);
                    chart1.SaveImage(FILE_NAME + "_" + Convert.ToDouble(textBox_integral_time.Text.Trim()) + "us" + ".Png", System.Windows.Forms.DataVisualization.Charting.ChartImageFormat.Png);
                    for (int i = 0; i < 3648; i++)
                    {
                        if (i > 4 && i < 3644)
                        {
                            if (min_p > Data_p[i])
                            {
                                min_p = Data_p[i];
                            }
                            else if (max_p < Data_p[i])
                            {
                                max_p = Data_p[i];
                            }
                        }
                    }
                    for (int i = 0; i < 3648; i++)
                    {

                        for (int j = 0; j < 800; j++)
                        {
                            if (i > 4 && i < 3644)
                            {
                                alpha_p2 = 0;
                                if (Data_p[i] != 0 && max_p > 0)
                                {
                                    alpha_p2 = Convert.ToInt16(255 - 255 * Data_p[i] / max_p);
                                }
                                bmp_sensor.SetPixel(i, j, Color.FromArgb(255, 255 - alpha_p2, 255 - alpha_p2, 255 - alpha_p2));
                            }
                            else
                            {
                                bmp_sensor.SetPixel(i, j, Color.FromArgb(255, 0, 0, 0));
                            }
                        }

                    }
                    bmp_sensor.Save(FILE_NAME + "_sensor" + "_" + Convert.ToDouble(textBox_integral_time.Text.Trim()) + "us" + ".Png", System.Drawing.Imaging.ImageFormat.Png);
                }
                else
                {
                    MessageBox.Show("\n 请先运行您的程序采集数据后再保存数据 \n", "警告信息", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                //return;
            }
        }
        void chart_GetToolTipText(object sender, ToolTipEventArgs e)
        {
            if (e.HitTestResult.ChartElementType == ChartElementType.DataPoint)
            {
                int i = e.HitTestResult.PointIndex;
                double x = chart1.ChartAreas[0].CursorX.Position;
                double y = chart1.ChartAreas[0].CursorY.Position;
                DataPoint dp = e.HitTestResult.Series.Points[i];
                //分别显示x轴和y轴的数值，其中{1:F3},表示显示的是float类型，精确到小数点后3位。  
                e.Text = string.Format("Pixel :{0};数值:{1:F3} ", dp.XValue, dp.YValues[0]);

                //this.label_point_data_viwer.Text = string.Format("|   峰值:{0}   (0~65535)  |   坐标:{1}   Pixel  |", dp.YValues[0], dp.XValue);
                this.label_point_data_viwer.Text = string.Format("|   峰值:{0}   (0~65535)  |   坐标:{1}   Pixel  |", y, x);
            }

        }

        private void button_ZoomOut_Click(object sender, EventArgs e)
        {
            chart1.ChartAreas[0].AxisX.ScaleView.ZoomReset(0);
            chart1.ChartAreas[0].AxisY.ScaleView.ZoomReset(0);
        }

        private void button_About_Click(object sender, EventArgs e)
        {
            Form_about Form_about_1 = new Form_about();
            Form_about_1.ShowDialog();
        }

        private void Load_Corrected_Spectra_File_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            //openFileDialog.InitialDirectory = "c:\\";//注意这里写路径时要用c:\\而不是c:\
            openFileDialog.Filter = "文本文件|*.*|所有文件|*.*";
            openFileDialog.RestoreDirectory = true;
            openFileDialog.FilterIndex = 1;
            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    using (FileStream stream = File.Open(openFileDialog.FileName, FileMode.Open, FileAccess.Read, FileShare.Read))
                    {
                        byte[] Corrected_Spectra_data = new byte[8000]; ;
                        stream.Seek(0, SeekOrigin.Begin);
                        stream.Read(Corrected_Spectra_data, 0, 8000);
                        MessageBox.Show(System.Text.Encoding.Default.GetString(Corrected_Spectra_data), "===", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
                catch(Exception  ex)
                {
                    MessageBox.Show(ex.Message, "警告信息", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
        }

        private void button_Corrected_Spectra_Click(object sender, EventArgs e)
        {

        }

        private void button_Corrected_Spectra_help_Click(object sender, EventArgs e)
        {
            Form_Corrected_Spectra_help Form_Corrected_Spectra_help_1 = new Form_Corrected_Spectra_help();
            Form_Corrected_Spectra_help_1.ShowDialog();
        }
    }
}
