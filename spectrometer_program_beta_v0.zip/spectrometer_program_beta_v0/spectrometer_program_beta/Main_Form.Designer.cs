﻿namespace spectrometer_program_beta
{
    partial class Main_Form
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea1 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend1 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series1 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Main_Form));
            this.tabControl = new System.Windows.Forms.TabControl();
            this.Main_Page = new System.Windows.Forms.TabPage();
            this.button_ZoomOut = new System.Windows.Forms.Button();
            this.label_point_data_viwer = new System.Windows.Forms.Label();
            this.show_max_label = new System.Windows.Forms.Label();
            this.button_save_data = new System.Windows.Forms.Button();
            this.button_pause = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.chart1 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.button_STOP = new System.Windows.Forms.Button();
            this.information_label = new System.Windows.Forms.Label();
            this.START = new System.Windows.Forms.Button();
            this.Setting_Page = new System.Windows.Forms.TabPage();
            this.button_About = new System.Windows.Forms.Button();
            this.button_rescan_device = new System.Windows.Forms.Button();
            this.label_connected_device = new System.Windows.Forms.Label();
            this.label_Hz = new System.Windows.Forms.Label();
            this.label_FPS = new System.Windows.Forms.Label();
            this.label_μs = new System.Windows.Forms.Label();
            this.label_Baud_rate = new System.Windows.Forms.Label();
            this.textBox_Baud_rate = new System.Windows.Forms.TextBox();
            this.comboBox_Selected_SerialPort = new System.Windows.Forms.ComboBox();
            this.Setting_Save = new System.Windows.Forms.Button();
            this.label_function_FPS = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.textBox_FPS = new System.Windows.Forms.TextBox();
            this.textBox_integral_time = new System.Windows.Forms.TextBox();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.button_Corrected_Spectra_help = new System.Windows.Forms.Button();
            this.button_Load_Corrected_Spectra_File = new System.Windows.Forms.Button();
            this.button_Corrected_Spectra = new System.Windows.Forms.Button();
            this.tabControl.SuspendLayout();
            this.Main_Page.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chart1)).BeginInit();
            this.Setting_Page.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl
            // 
            this.tabControl.Controls.Add(this.Main_Page);
            this.tabControl.Controls.Add(this.Setting_Page);
            this.tabControl.Controls.Add(this.tabPage1);
            this.tabControl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl.Location = new System.Drawing.Point(0, 0);
            this.tabControl.Name = "tabControl";
            this.tabControl.SelectedIndex = 0;
            this.tabControl.Size = new System.Drawing.Size(1424, 771);
            this.tabControl.TabIndex = 0;
            // 
            // Main_Page
            // 
            this.Main_Page.BackColor = System.Drawing.Color.Wheat;
            this.Main_Page.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.Main_Page.Controls.Add(this.button_ZoomOut);
            this.Main_Page.Controls.Add(this.label_point_data_viwer);
            this.Main_Page.Controls.Add(this.show_max_label);
            this.Main_Page.Controls.Add(this.button_save_data);
            this.Main_Page.Controls.Add(this.button_pause);
            this.Main_Page.Controls.Add(this.label2);
            this.Main_Page.Controls.Add(this.pictureBox1);
            this.Main_Page.Controls.Add(this.chart1);
            this.Main_Page.Controls.Add(this.button_STOP);
            this.Main_Page.Controls.Add(this.information_label);
            this.Main_Page.Controls.Add(this.START);
            this.Main_Page.Location = new System.Drawing.Point(4, 22);
            this.Main_Page.Name = "Main_Page";
            this.Main_Page.Padding = new System.Windows.Forms.Padding(3);
            this.Main_Page.Size = new System.Drawing.Size(1416, 745);
            this.Main_Page.TabIndex = 0;
            this.Main_Page.Text = "Main_Page";
            // 
            // button_ZoomOut
            // 
            this.button_ZoomOut.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.button_ZoomOut.Location = new System.Drawing.Point(1221, 52);
            this.button_ZoomOut.Name = "button_ZoomOut";
            this.button_ZoomOut.Size = new System.Drawing.Size(93, 40);
            this.button_ZoomOut.TabIndex = 13;
            this.button_ZoomOut.Text = "Zoom Out";
            this.button_ZoomOut.UseVisualStyleBackColor = true;
            this.button_ZoomOut.Click += new System.EventHandler(this.button_ZoomOut_Click);
            // 
            // label_point_data_viwer
            // 
            this.label_point_data_viwer.AutoSize = true;
            this.label_point_data_viwer.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F);
            this.label_point_data_viwer.Location = new System.Drawing.Point(95, 17);
            this.label_point_data_viwer.Name = "label_point_data_viwer";
            this.label_point_data_viwer.Size = new System.Drawing.Size(129, 29);
            this.label_point_data_viwer.TabIndex = 12;
            this.label_point_data_viwer.Text = "data_viwer";
            // 
            // show_max_label
            // 
            this.show_max_label.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.show_max_label.AutoSize = true;
            this.show_max_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.show_max_label.Location = new System.Drawing.Point(1025, 729);
            this.show_max_label.Name = "show_max_label";
            this.show_max_label.Size = new System.Drawing.Size(54, 13);
            this.show_max_label.TabIndex = 11;
            this.show_max_label.Text = "max_label";
            // 
            // button_save_data
            // 
            this.button_save_data.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.button_save_data.Location = new System.Drawing.Point(1221, 6);
            this.button_save_data.Name = "button_save_data";
            this.button_save_data.Size = new System.Drawing.Size(93, 40);
            this.button_save_data.TabIndex = 10;
            this.button_save_data.Text = "SAVE_DATA";
            this.button_save_data.UseVisualStyleBackColor = true;
            this.button_save_data.Click += new System.EventHandler(this.button_save_data_Click);
            // 
            // button_pause
            // 
            this.button_pause.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.button_pause.Location = new System.Drawing.Point(1320, 6);
            this.button_pause.Name = "button_pause";
            this.button_pause.Size = new System.Drawing.Size(93, 40);
            this.button_pause.TabIndex = 9;
            this.button_pause.Text = "PAUSE";
            this.button_pause.UseVisualStyleBackColor = true;
            this.button_pause.Click += new System.EventHandler(this.button_pause_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.label2.Location = new System.Drawing.Point(8, 65);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(88, 24);
            this.label2.TabIndex = 6;
            this.label2.Text = "TCD1304";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox1.BackColor = System.Drawing.SystemColors.HighlightText;
            this.pictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox1.Location = new System.Drawing.Point(100, 65);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(1072, 27);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 5;
            this.pictureBox1.TabStop = false;
            // 
            // chart1
            // 
            this.chart1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.chart1.BackColor = System.Drawing.Color.Turquoise;
            this.chart1.BorderlineColor = System.Drawing.Color.Transparent;
            chartArea1.AxisX.MajorGrid.Enabled = false;
            chartArea1.AxisX.Title = "Pixel";
            chartArea1.AxisY.MajorGrid.Enabled = false;
            chartArea1.AxisY.TextOrientation = System.Windows.Forms.DataVisualization.Charting.TextOrientation.Horizontal;
            chartArea1.AxisY.Title = "I";
            chartArea1.AxisY.TitleAlignment = System.Drawing.StringAlignment.Far;
            chartArea1.BackColor = System.Drawing.Color.White;
            chartArea1.BackImageWrapMode = System.Windows.Forms.DataVisualization.Charting.ChartImageWrapMode.Scaled;
            chartArea1.BorderColor = System.Drawing.Color.White;
            chartArea1.CursorX.IsUserEnabled = true;
            chartArea1.CursorX.IsUserSelectionEnabled = true;
            chartArea1.CursorY.IsUserEnabled = true;
            chartArea1.CursorY.IsUserSelectionEnabled = true;
            chartArea1.Name = "ChartArea1";
            this.chart1.ChartAreas.Add(chartArea1);
            legend1.Enabled = false;
            legend1.Name = "Legend1";
            this.chart1.Legends.Add(legend1);
            this.chart1.Location = new System.Drawing.Point(0, 98);
            this.chart1.Name = "chart1";
            series1.ChartArea = "ChartArea1";
            series1.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            series1.LabelToolTip = "#VALX #VAL";
            series1.Legend = "Legend1";
            series1.Name = "Series1";
            series1.ToolTip = "#VAL{G} #VALX{G}";
            this.chart1.Series.Add(series1);
            this.chart1.Size = new System.Drawing.Size(1416, 617);
            this.chart1.TabIndex = 4;
            this.chart1.Text = "chart1";
            this.chart1.GetToolTipText += new System.EventHandler<System.Windows.Forms.DataVisualization.Charting.ToolTipEventArgs>(this.chart_GetToolTipText);
            // 
            // button_STOP
            // 
            this.button_STOP.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.button_STOP.Location = new System.Drawing.Point(1122, 6);
            this.button_STOP.Name = "button_STOP";
            this.button_STOP.Size = new System.Drawing.Size(93, 40);
            this.button_STOP.TabIndex = 3;
            this.button_STOP.Text = "STOP";
            this.button_STOP.UseVisualStyleBackColor = true;
            this.button_STOP.Click += new System.EventHandler(this.button_STOP_Click);
            // 
            // information_label
            // 
            this.information_label.AutoSize = true;
            this.information_label.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.information_label.Location = new System.Drawing.Point(3, 729);
            this.information_label.Name = "information_label";
            this.information_label.Size = new System.Drawing.Size(86, 13);
            this.information_label.TabIndex = 2;
            this.information_label.Text = "information_label";
            // 
            // START
            // 
            this.START.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.START.Location = new System.Drawing.Point(1320, 52);
            this.START.Name = "START";
            this.START.Size = new System.Drawing.Size(93, 40);
            this.START.TabIndex = 1;
            this.START.Text = "START";
            this.START.UseVisualStyleBackColor = true;
            this.START.Click += new System.EventHandler(this.START_Click);
            // 
            // Setting_Page
            // 
            this.Setting_Page.BackgroundImage = global::spectrometer_program_beta.Properties.Resources.wallhaven_620994;
            this.Setting_Page.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Setting_Page.Controls.Add(this.button_About);
            this.Setting_Page.Controls.Add(this.button_rescan_device);
            this.Setting_Page.Controls.Add(this.label_connected_device);
            this.Setting_Page.Controls.Add(this.label_Hz);
            this.Setting_Page.Controls.Add(this.label_FPS);
            this.Setting_Page.Controls.Add(this.label_μs);
            this.Setting_Page.Controls.Add(this.label_Baud_rate);
            this.Setting_Page.Controls.Add(this.textBox_Baud_rate);
            this.Setting_Page.Controls.Add(this.comboBox_Selected_SerialPort);
            this.Setting_Page.Controls.Add(this.Setting_Save);
            this.Setting_Page.Controls.Add(this.label_function_FPS);
            this.Setting_Page.Controls.Add(this.label1);
            this.Setting_Page.Controls.Add(this.textBox_FPS);
            this.Setting_Page.Controls.Add(this.textBox_integral_time);
            this.Setting_Page.Location = new System.Drawing.Point(4, 22);
            this.Setting_Page.Name = "Setting_Page";
            this.Setting_Page.Padding = new System.Windows.Forms.Padding(3);
            this.Setting_Page.Size = new System.Drawing.Size(1416, 745);
            this.Setting_Page.TabIndex = 1;
            this.Setting_Page.Text = "Setting_Page";
            this.Setting_Page.UseVisualStyleBackColor = true;
            // 
            // button_About
            // 
            this.button_About.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F);
            this.button_About.Location = new System.Drawing.Point(30, 22);
            this.button_About.Name = "button_About";
            this.button_About.Size = new System.Drawing.Size(99, 46);
            this.button_About.TabIndex = 21;
            this.button_About.Text = "About";
            this.button_About.UseVisualStyleBackColor = true;
            this.button_About.Click += new System.EventHandler(this.button_About_Click);
            // 
            // button_rescan_device
            // 
            this.button_rescan_device.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.button_rescan_device.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.button_rescan_device.Location = new System.Drawing.Point(1294, 115);
            this.button_rescan_device.Name = "button_rescan_device";
            this.button_rescan_device.Size = new System.Drawing.Size(102, 23);
            this.button_rescan_device.TabIndex = 20;
            this.button_rescan_device.Text = "刷新设备";
            this.button_rescan_device.UseVisualStyleBackColor = true;
            this.button_rescan_device.Click += new System.EventHandler(this.button_rescan_device_Click);
            // 
            // label_connected_device
            // 
            this.label_connected_device.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label_connected_device.AutoSize = true;
            this.label_connected_device.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.label_connected_device.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_connected_device.Location = new System.Drawing.Point(1069, 115);
            this.label_connected_device.Name = "label_connected_device";
            this.label_connected_device.Size = new System.Drawing.Size(73, 20);
            this.label_connected_device.TabIndex = 19;
            this.label_connected_device.Text = "连接设备";
            // 
            // label_Hz
            // 
            this.label_Hz.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label_Hz.AutoSize = true;
            this.label_Hz.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.label_Hz.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_Hz.Location = new System.Drawing.Point(1290, 12);
            this.label_Hz.Name = "label_Hz";
            this.label_Hz.Size = new System.Drawing.Size(29, 20);
            this.label_Hz.TabIndex = 18;
            this.label_Hz.Text = "Hz";
            // 
            // label_FPS
            // 
            this.label_FPS.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label_FPS.AutoSize = true;
            this.label_FPS.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.label_FPS.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_FPS.Location = new System.Drawing.Point(1290, 62);
            this.label_FPS.Name = "label_FPS";
            this.label_FPS.Size = new System.Drawing.Size(77, 20);
            this.label_FPS.TabIndex = 17;
            this.label_FPS.Text = "FPS(1~5)";
            // 
            // label_μs
            // 
            this.label_μs.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label_μs.AutoSize = true;
            this.label_μs.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.label_μs.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_μs.Location = new System.Drawing.Point(1290, 38);
            this.label_μs.Name = "label_μs";
            this.label_μs.Size = new System.Drawing.Size(106, 20);
            this.label_μs.TabIndex = 16;
            this.label_μs.Text = "μs(10μs~10s)";
            // 
            // label_Baud_rate
            // 
            this.label_Baud_rate.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label_Baud_rate.AutoSize = true;
            this.label_Baud_rate.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.label_Baud_rate.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_Baud_rate.Location = new System.Drawing.Point(1085, 12);
            this.label_Baud_rate.Name = "label_Baud_rate";
            this.label_Baud_rate.Size = new System.Drawing.Size(57, 20);
            this.label_Baud_rate.TabIndex = 14;
            this.label_Baud_rate.Text = "波特率";
            // 
            // textBox_Baud_rate
            // 
            this.textBox_Baud_rate.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.textBox_Baud_rate.Location = new System.Drawing.Point(1184, 12);
            this.textBox_Baud_rate.Name = "textBox_Baud_rate";
            this.textBox_Baud_rate.Size = new System.Drawing.Size(100, 20);
            this.textBox_Baud_rate.TabIndex = 15;
            this.textBox_Baud_rate.Text = "921600";
            // 
            // comboBox_Selected_SerialPort
            // 
            this.comboBox_Selected_SerialPort.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.comboBox_Selected_SerialPort.Cursor = System.Windows.Forms.Cursors.Default;
            this.comboBox_Selected_SerialPort.DropDownHeight = 120;
            this.comboBox_Selected_SerialPort.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_Selected_SerialPort.IntegralHeight = false;
            this.comboBox_Selected_SerialPort.Location = new System.Drawing.Point(1184, 117);
            this.comboBox_Selected_SerialPort.Name = "comboBox_Selected_SerialPort";
            this.comboBox_Selected_SerialPort.Size = new System.Drawing.Size(100, 21);
            this.comboBox_Selected_SerialPort.TabIndex = 8;
            // 
            // Setting_Save
            // 
            this.Setting_Save.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.Setting_Save.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.Setting_Save.Location = new System.Drawing.Point(1184, 608);
            this.Setting_Save.Name = "Setting_Save";
            this.Setting_Save.Size = new System.Drawing.Size(141, 61);
            this.Setting_Save.TabIndex = 13;
            this.Setting_Save.Text = "Save_Setting";
            this.Setting_Save.UseVisualStyleBackColor = true;
            this.Setting_Save.Click += new System.EventHandler(this.Setting_Save_Click);
            // 
            // label_function_FPS
            // 
            this.label_function_FPS.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label_function_FPS.AutoSize = true;
            this.label_function_FPS.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.label_function_FPS.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_function_FPS.Location = new System.Drawing.Point(1053, 64);
            this.label_function_FPS.Name = "label_function_FPS";
            this.label_function_FPS.Size = new System.Drawing.Size(89, 20);
            this.label_function_FPS.TabIndex = 10;
            this.label_function_FPS.Text = "图像刷新率";
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(1069, 38);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(73, 20);
            this.label1.TabIndex = 9;
            this.label1.Text = "积分时间";
            // 
            // textBox_FPS
            // 
            this.textBox_FPS.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.textBox_FPS.Location = new System.Drawing.Point(1184, 64);
            this.textBox_FPS.Name = "textBox_FPS";
            this.textBox_FPS.Size = new System.Drawing.Size(100, 20);
            this.textBox_FPS.TabIndex = 11;
            this.textBox_FPS.Text = "5";
            // 
            // textBox_integral_time
            // 
            this.textBox_integral_time.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.textBox_integral_time.Location = new System.Drawing.Point(1184, 38);
            this.textBox_integral_time.Name = "textBox_integral_time";
            this.textBox_integral_time.Size = new System.Drawing.Size(100, 20);
            this.textBox_integral_time.TabIndex = 12;
            this.textBox_integral_time.Text = "50";
            // 
            // tabPage1
            // 
            this.tabPage1.BackgroundImage = global::spectrometer_program_beta.Properties.Resources.wallhaven_620994;
            this.tabPage1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.tabPage1.Controls.Add(this.button_Corrected_Spectra_help);
            this.tabPage1.Controls.Add(this.button_Load_Corrected_Spectra_File);
            this.tabPage1.Controls.Add(this.button_Corrected_Spectra);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(1416, 745);
            this.tabPage1.TabIndex = 2;
            this.tabPage1.Text = "Corrected_Spectra";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // button_Corrected_Spectra_help
            // 
            this.button_Corrected_Spectra_help.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.button_Corrected_Spectra_help.Location = new System.Drawing.Point(1314, 38);
            this.button_Corrected_Spectra_help.Name = "button_Corrected_Spectra_help";
            this.button_Corrected_Spectra_help.Size = new System.Drawing.Size(53, 23);
            this.button_Corrected_Spectra_help.TabIndex = 16;
            this.button_Corrected_Spectra_help.Text = "Help";
            this.button_Corrected_Spectra_help.UseVisualStyleBackColor = true;
            this.button_Corrected_Spectra_help.Click += new System.EventHandler(this.button_Corrected_Spectra_help_Click);
            // 
            // button_Load_Corrected_Spectra_File
            // 
            this.button_Load_Corrected_Spectra_File.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.button_Load_Corrected_Spectra_File.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.button_Load_Corrected_Spectra_File.Location = new System.Drawing.Point(1203, 571);
            this.button_Load_Corrected_Spectra_File.Name = "button_Load_Corrected_Spectra_File";
            this.button_Load_Corrected_Spectra_File.Size = new System.Drawing.Size(165, 36);
            this.button_Load_Corrected_Spectra_File.TabIndex = 15;
            this.button_Load_Corrected_Spectra_File.Text = "Load_Corrected_Spectra_File";
            this.button_Load_Corrected_Spectra_File.UseVisualStyleBackColor = true;
            this.button_Load_Corrected_Spectra_File.Click += new System.EventHandler(this.Load_Corrected_Spectra_File_Click);
            // 
            // button_Corrected_Spectra
            // 
            this.button_Corrected_Spectra.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.button_Corrected_Spectra.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.button_Corrected_Spectra.Location = new System.Drawing.Point(1203, 623);
            this.button_Corrected_Spectra.Name = "button_Corrected_Spectra";
            this.button_Corrected_Spectra.Size = new System.Drawing.Size(165, 61);
            this.button_Corrected_Spectra.TabIndex = 14;
            this.button_Corrected_Spectra.Text = "Corrected_Spectra";
            this.button_Corrected_Spectra.UseVisualStyleBackColor = true;
            this.button_Corrected_Spectra.Click += new System.EventHandler(this.button_Corrected_Spectra_Click);
            // 
            // Main_Form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1424, 771);
            this.Controls.Add(this.tabControl);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Main_Form";
            this.Text = "Main_Form";
            this.tabControl.ResumeLayout(false);
            this.Main_Page.ResumeLayout(false);
            this.Main_Page.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chart1)).EndInit();
            this.Setting_Page.ResumeLayout(false);
            this.Setting_Page.PerformLayout();
            this.tabPage1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl;
        private System.Windows.Forms.TabPage Main_Page;
        private System.Windows.Forms.TabPage Setting_Page;
        private System.Windows.Forms.Button START;
        private System.Windows.Forms.ComboBox comboBox_Selected_SerialPort;
        private System.Windows.Forms.Button Setting_Save;
        private System.Windows.Forms.Label label_function_FPS;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBox_FPS;
        private System.Windows.Forms.TextBox textBox_integral_time;
        private System.Windows.Forms.Label information_label;
        private System.Windows.Forms.Label label_Baud_rate;
        private System.Windows.Forms.TextBox textBox_Baud_rate;
        private System.Windows.Forms.Label label_Hz;
        private System.Windows.Forms.Label label_FPS;
        private System.Windows.Forms.Label label_μs;
        private System.Windows.Forms.Label label_connected_device;
        private System.Windows.Forms.Button button_STOP;
        private System.Windows.Forms.DataVisualization.Charting.Chart chart1;
        private System.Windows.Forms.Button button_rescan_device;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button button_pause;
        private System.Windows.Forms.Button button_save_data;
        private System.Windows.Forms.Label show_max_label;
        private System.Windows.Forms.Label label_point_data_viwer;
        private System.Windows.Forms.Button button_ZoomOut;
        private System.Windows.Forms.Button button_About;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Button button_Corrected_Spectra;
        private System.Windows.Forms.Button button_Load_Corrected_Spectra_File;
        private System.Windows.Forms.Button button_Corrected_Spectra_help;
    }
}

